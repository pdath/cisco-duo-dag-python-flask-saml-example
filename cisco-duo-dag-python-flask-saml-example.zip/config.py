SAML_METADATA_URL='https://yourdagserver.com/dag/saml2/idp/metadata.php'
SAML_ENTITY_ID='https://yourappserver.com'